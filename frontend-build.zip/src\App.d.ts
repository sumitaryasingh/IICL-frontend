import React from "react";
import "./App.css";
import "react-toastify/dist/ReactToastify.css";
declare const App: React.FC;
export default App;
