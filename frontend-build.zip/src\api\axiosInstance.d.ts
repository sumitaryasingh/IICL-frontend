declare const axioInstance: import("axios").AxiosInstance;
export default axioInstance;
