export declare const programData: any;
