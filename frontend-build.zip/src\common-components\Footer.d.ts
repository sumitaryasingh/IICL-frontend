import React from "react";
import "./Footer.css";
declare const Footer: React.FC;
export default Footer;
