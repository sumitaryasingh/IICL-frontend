import React from 'react';
import './AboutUs.css';
declare const AboutUs: React.FC;
export default AboutUs;
