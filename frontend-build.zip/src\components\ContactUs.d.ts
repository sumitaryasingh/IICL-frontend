import React from 'react';
import 'react-toastify/dist/ReactToastify.css';
import './ContactUs.css';
declare const ContactUs: React.FC;
export default ContactUs;
