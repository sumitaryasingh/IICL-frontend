import React from "react";
import "./styles/franchiseParent.css";
declare const Franchise: React.FC;
export default Franchise;
