import React from "react";
import "./styles/franchiseBenefits.css";
declare const FranchiseBenefits: React.FC;
export default FranchiseBenefits;
