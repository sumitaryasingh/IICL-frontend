import React from 'react';
import './styles/FranchiseForm.css';
import 'react-toastify/dist/ReactToastify.css';
declare const FranchiseLogin: React.FC;
export default FranchiseLogin;
