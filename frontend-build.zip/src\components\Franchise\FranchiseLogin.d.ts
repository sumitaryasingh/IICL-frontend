import "./styles/franchiseAuth.css";
declare const FranchiseLogin: () => import("react/jsx-runtime").JSX.Element;
export default FranchiseLogin;
