import React from "react";
import "./styles/franchiseProcedure.css";
declare const FranchiseProcedure: React.FC;
export default FranchiseProcedure;
