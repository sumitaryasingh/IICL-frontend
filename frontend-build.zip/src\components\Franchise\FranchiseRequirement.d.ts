import React from "react";
import "./styles/franchiseRequirement.css";
declare const FranchiseRequirement: React.FC;
export default FranchiseRequirement;
