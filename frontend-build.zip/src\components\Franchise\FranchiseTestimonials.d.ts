import React from "react";
import "./styles/franchiseTestimonials.css";
declare const FranchiseTestimonials: React.FC;
export default FranchiseTestimonials;
