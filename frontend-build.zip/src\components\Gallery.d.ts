import React from "react";
import "./Gallery.css";
declare const Gallery: React.FC;
export default Gallery;
