import React from "react";
import "./Home.css";
declare const Attract: React.FC;
export default Attract;
