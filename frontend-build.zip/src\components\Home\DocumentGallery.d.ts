import React from "react";
declare const DocumentGallery: React.FC;
export default DocumentGallery;
