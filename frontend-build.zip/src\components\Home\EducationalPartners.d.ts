import React from "react";
import "./Home.css";
declare const EducationalPartners: React.FC;
export default EducationalPartners;
