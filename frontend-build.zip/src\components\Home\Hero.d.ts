import React from "react";
import "./Hero.css";
type HeroProps = {
    scrollToStory: () => void;
};
declare const Hero: React.FC<HeroProps>;
export default Hero;
