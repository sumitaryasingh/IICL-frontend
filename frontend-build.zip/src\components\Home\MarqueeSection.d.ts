import React from 'react';
import './MarqueeSection.css';
declare const MarqueeSection: React.FC;
export default MarqueeSection;
