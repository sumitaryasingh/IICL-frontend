import React from "react";
import "./Home.css";
declare const StatsSection: React.FC;
export default StatsSection;
