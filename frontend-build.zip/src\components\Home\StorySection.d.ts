import React from "react";
import "./Home.css";
declare const WelcomeSection: React.FC;
export default WelcomeSection;
