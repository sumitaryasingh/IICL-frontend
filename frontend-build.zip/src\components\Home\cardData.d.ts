export type Card = {
    title: string;
    description: string;
    link: string;
};
export declare const cards: Card[];
