import React from "react";
import "react-toastify/dist/ReactToastify.css";
declare const AddBatchForm: React.FC;
export default AddBatchForm;
