import React from "react";
import "react-toastify/dist/ReactToastify.css";
declare const AddFranchiseForm: React.FC;
export default AddFranchiseForm;
