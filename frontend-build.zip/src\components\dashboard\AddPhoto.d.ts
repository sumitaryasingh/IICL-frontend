import React from "react";
import "react-toastify/dist/ReactToastify.css";
declare const AddPhoto: React.FC;
export default AddPhoto;
