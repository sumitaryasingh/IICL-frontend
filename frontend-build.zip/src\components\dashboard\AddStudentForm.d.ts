import React from "react";
import "react-toastify/dist/ReactToastify.css";
declare const AddStudentForm: React.FC;
export default AddStudentForm;
