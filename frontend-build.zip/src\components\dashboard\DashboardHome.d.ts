import React from "react";
declare const DashboardHome: React.FC;
export default DashboardHome;
