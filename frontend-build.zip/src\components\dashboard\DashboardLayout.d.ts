import React from "react";
interface DashboardLayoutProps {
    children: React.ReactNode;
}
declare const DashboardLayout: React.FC<DashboardLayoutProps>;
export default DashboardLayout;
