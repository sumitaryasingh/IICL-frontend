import React from "react";
interface DashboardSidebarProps {
    isOpen: boolean;
    toggleSidebar: () => void;
}
declare const _default: React.NamedExoticComponent<DashboardSidebarProps>;
export default _default;
