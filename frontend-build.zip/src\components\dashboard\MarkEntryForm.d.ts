import React from "react";
declare const MarkEntryForm: React.FC;
export default MarkEntryForm;
