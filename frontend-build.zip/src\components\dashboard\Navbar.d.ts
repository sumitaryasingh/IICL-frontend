declare const Navbar: () => import("react/jsx-runtime").JSX.Element;
export default Navbar;
