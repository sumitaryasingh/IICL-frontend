import React from 'react';
declare const ProfileComponent: React.FC;
export default ProfileComponent;
