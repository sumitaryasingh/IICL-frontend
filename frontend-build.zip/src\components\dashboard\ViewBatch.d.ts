import React from "react";
declare const ViewBatch: React.FC;
export default ViewBatch;
