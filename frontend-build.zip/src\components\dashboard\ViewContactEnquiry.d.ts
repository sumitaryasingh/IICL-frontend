import React from "react";
declare const ViewContactEnquiry: React.FC;
export default ViewContactEnquiry;
