import React from "react";
declare const ViewFranchise: React.FC;
export default ViewFranchise;
