import React from "react";
declare const ViewFranchiseEnquiry: React.FC;
export default ViewFranchiseEnquiry;
