import React from "react";
declare const ViewStudent: React.FC;
export default ViewStudent;
