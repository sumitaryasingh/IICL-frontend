import React from "react";
declare const ProtectedRoute: React.FC;
export default ProtectedRoute;
