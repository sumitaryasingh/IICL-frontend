export default function ProgrammeList(): import("react/jsx-runtime").JSX.Element;
