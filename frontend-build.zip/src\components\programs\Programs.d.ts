export default function Programme(): import("react/jsx-runtime").JSX.Element;
