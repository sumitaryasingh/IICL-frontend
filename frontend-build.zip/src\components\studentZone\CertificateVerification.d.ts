import React from "react";
import "./styles/CertificateVerification.css";
declare const CertificateVerification: React.FC;
export default CertificateVerification;
