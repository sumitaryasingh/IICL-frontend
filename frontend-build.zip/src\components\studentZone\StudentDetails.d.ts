import React from "react";
import "./styles/StudentDetails.css";
declare const StudentDetails: React.FC;
export default StudentDetails;
