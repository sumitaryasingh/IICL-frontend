import "./styles/StudentEnrollment.css";
declare const StudentEnrollment: () => import("react/jsx-runtime").JSX.Element;
export default StudentEnrollment;
