import React from "react";
declare const Student: React.FC;
export default Student;
