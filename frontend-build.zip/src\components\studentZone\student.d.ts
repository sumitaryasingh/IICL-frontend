declare const Student: React.FC;
export default Student;
