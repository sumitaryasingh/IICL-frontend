export declare const submitFranchiseForm: (formData: any) => Promise<any>;
