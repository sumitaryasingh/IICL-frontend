export declare const registerUser: (data: {
    name?: string;
    email: string;
    password: string;
}) => Promise<void>;
