export declare const uploadPhoto: (file: File) => Promise<any>;
