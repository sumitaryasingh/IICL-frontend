export declare const fetchStudentDetails: (enrollmentId: string) => Promise<any>;
export declare const checkStudentExistsOrNot: (enrollmentId: string) => Promise<any>;
